import pandas as pd 
import seaborn as sns
import matplotlib.pyplot as plt

oo = pd.read_csv('../athlete_events.csv')

