import os 

if os.getlogin() == "root":
    print("Error")