import math

def transform(radians): 
    return print(radians * 180/math.pi)

transform(1)