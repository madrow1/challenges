
#Function takes in 2 params, and returns a discounted value
def discount(price,discount):
    return print(price - (price * (discount/100)))


discount(100,20)