import tkinter as tk

window = tk.Tk()

window.geometry("700x300")

window.configure(bg='blue')

greeting = tk.Label(text="Hello, world", fg="white")
greeting.place(x=70,y=70)

window.mainloop()