from collections import deque

def main():

    class task:
        def __init__(self, add, addHigh):
            self.add = add
            self.addHigh = addHigh
         

 

    

if __name__ == "__main__":
    main()